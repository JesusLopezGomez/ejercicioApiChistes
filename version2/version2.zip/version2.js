let fs = require("fs");
let prompt = require('prompt');
prompt.start();
prompt.get(['termino'], function (err, result) {
    if(result.termino == "leaderboard"){
        fs.readFile("chistes.txt",(err, data)=> {
            if(err) throw err;
            for(chiste in data.toString()){
                /*Me quedaría meter cada chiste en una array y compararlas pero no me da tiempo*/
            }
        });
    }

});